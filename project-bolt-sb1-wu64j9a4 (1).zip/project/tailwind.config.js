/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'ps-bg': '#061226',
        'ps-sidebar': '#030B18',
        'ps-card': '#0B1B33',
        'ps-cyan': '#00E5FF',
        'ps-purple': '#8B5CF6',
        'ps-risk-high': '#FF4D67',
        'ps-risk-medium': '#FBBF24',
        'ps-risk-low': '#10D9A0',
      },
    },
  },
  plugins: [],
};
