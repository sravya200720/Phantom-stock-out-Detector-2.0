import { Package, Layers, IndianRupee, AlertTriangle, Ghost, TrendingDown, ArrowRight } from 'lucide-react';
import type { DashboardMetrics, ProductWithMetrics, View } from '@/types';
import { formatINR } from '@/lib/inventory';
import { RiskBadge } from './RiskBadge';

interface DashboardProps {
  metrics: DashboardMetrics;
  products: ProductWithMetrics[];
  onNavigate: (view: View) => void;
  onSelectProduct: (sku: string) => void;
}

export function Dashboard({ metrics, products, onNavigate, onSelectProduct }: DashboardProps) {
  const cards = [
    { label: 'Total Products', value: metrics.totalProducts.toString(), icon: Package, color: 'text-ps-cyan', bg: 'from-ps-cyan/10' },
    { label: 'Total Categories', value: metrics.totalCategories.toString(), icon: Layers, color: 'text-ps-purple', bg: 'from-ps-purple/10' },
    { label: 'Total Inventory Value', value: formatINR(metrics.totalInventoryValue), icon: IndianRupee, color: 'text-ps-risk-low', bg: 'from-ps-risk-low/10' },
    { label: 'High-Risk Products', value: metrics.highRiskCount.toString(), icon: AlertTriangle, color: 'text-ps-risk-high', bg: 'from-ps-risk-high/10' },
    { label: 'Suspected Phantom Stock-Outs', value: metrics.suspectedPhantomCount.toString(), icon: Ghost, color: 'text-ps-risk-medium', bg: 'from-ps-risk-medium/10' },
    { label: 'Predicted Stock-Outs', value: metrics.predictedStockOuts.toString(), icon: TrendingDown, color: 'text-ps-risk-high', bg: 'from-ps-risk-high/10' },
  ];

  const highRiskProducts = products
    .filter((p) => p.stockOutRisk === 'high')
    .sort((a, b) => b.riskScore - a.riskScore)
    .slice(0, 5);

  const phantomProducts = products
    .filter((p) => p.phantomDiscrepancy !== null && Math.abs(p.phantomDiscrepancy) > 0)
    .slice(0, 5);

  // Category breakdown
  const categoryStats = new Map<string, { count: number; highRisk: number }>();
  for (const p of products) {
    const stat = categoryStats.get(p.category) ?? { count: 0, highRisk: 0 };
    stat.count++;
    if (p.stockOutRisk === 'high') stat.highRisk++;
    categoryStats.set(p.category, stat);
  }

  return (
    <div className="space-y-6 fade-in">
      {/* Page Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Inventory Intelligence Dashboard</h2>
        <p className="mt-1 text-sm text-slate-400">
          Real-time metrics computed from the actual product dataset of {metrics.totalProducts} products across {metrics.totalCategories} categories.
        </p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.label}
              className={`relative overflow-hidden rounded-xl border border-white/5 bg-ps-card bg-gradient-to-br ${card.bg} to-transparent p-4 transition-all duration-200 hover:border-white/10`}
            >
              <Icon className={`mb-3 h-6 w-6 ${card.color}`} />
              <p className="text-2xl font-bold text-white">{card.value}</p>
              <p className="mt-1 text-xs font-medium leading-tight text-slate-400">{card.label}</p>
            </div>
          );
        })}
      </div>

      {/* Risk Distribution Bar */}
      <div className="rounded-xl border border-white/5 bg-ps-card p-5">
        <h3 className="text-sm font-bold text-white mb-4">Risk Distribution</h3>
        <div className="flex h-3 w-full overflow-hidden rounded-full">
          {(() => {
            const high = products.filter((p) => p.stockOutRisk === 'high').length;
            const med = products.filter((p) => p.stockOutRisk === 'medium').length;
            const low = products.filter((p) => p.stockOutRisk === 'low').length;
            const total = products.length;
            return (
              <>
                <div className="bg-ps-risk-high" style={{ width: `${(high / total) * 100}%` }} />
                <div className="bg-ps-risk-medium" style={{ width: `${(med / total) * 100}%` }} />
                <div className="bg-ps-risk-low" style={{ width: `${(low / total) * 100}%` }} />
              </>
            );
          })()}
        </div>
        <div className="mt-3 flex flex-wrap gap-4 text-xs">
          <span className="flex items-center gap-1.5 text-slate-400">
            <span className="h-2.5 w-2.5 rounded-full bg-ps-risk-high" /> High Risk ({products.filter((p) => p.stockOutRisk === 'high').length})
          </span>
          <span className="flex items-center gap-1.5 text-slate-400">
            <span className="h-2.5 w-2.5 rounded-full bg-ps-risk-medium" /> Medium Risk ({products.filter((p) => p.stockOutRisk === 'medium').length})
          </span>
          <span className="flex items-center gap-1.5 text-slate-400">
            <span className="h-2.5 w-2.5 rounded-full bg-ps-risk-low" /> Low Risk ({products.filter((p) => p.stockOutRisk === 'low').length})
          </span>
        </div>
      </div>

      {/* Two-column section */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* High Risk Products */}
        <div className="rounded-xl border border-white/5 bg-ps-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">Top High-Risk Products</h3>
            <button
              onClick={() => onNavigate('predictions')}
              className="flex items-center gap-1 text-xs font-medium text-ps-cyan hover:gap-2 transition-all"
            >
              View all <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {highRiskProducts.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">No high-risk products detected.</p>
          ) : (
            <ul className="space-y-2">
              {highRiskProducts.map((p) => (
                <li key={p.sku}>
                  <button
                    onClick={() => onSelectProduct(p.sku)}
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                  >
                    <img src={p.image} alt={p.name} className="h-10 w-10 flex-shrink-0 rounded-lg object-cover" loading="lazy" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-200">{p.name}</p>
                      <p className="text-xs text-slate-500">{p.sku} · Stock: {p.recordedStock} · {p.dailySales}/day</p>
                    </div>
                    <RiskBadge risk={p.stockOutRisk} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Phantom Discrepancies */}
        <div className="rounded-xl border border-white/5 bg-ps-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-white">Phantom Stock-Out Alerts</h3>
            <button
              onClick={() => onNavigate('phantom')}
              className="flex items-center gap-1 text-xs font-medium text-ps-cyan hover:gap-2 transition-all"
            >
              View all <ArrowRight className="h-3 w-3" />
            </button>
          </div>
          {phantomProducts.length === 0 ? (
            <p className="text-sm text-slate-500 py-8 text-center">No discrepancies detected.</p>
          ) : (
            <ul className="space-y-2">
              {phantomProducts.map((p) => (
                <li key={p.sku}>
                  <button
                    onClick={() => onSelectProduct(p.sku)}
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-left transition-colors hover:bg-white/5"
                  >
                    <img src={p.image} alt={p.name} className="h-10 w-10 flex-shrink-0 rounded-lg object-cover" loading="lazy" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-slate-200">{p.name}</p>
                      <p className="text-xs text-slate-500">
                        Recorded: {p.recordedStock} · Verified: {p.verifiedStock} · Diff: {p.phantomDiscrepancy! > 0 ? '+' : ''}{p.phantomDiscrepancy}
                      </p>
                    </div>
                    <span className={`text-xs font-bold ${p.phantomDiscrepancy! > 0 ? 'text-ps-risk-medium' : 'text-ps-risk-high'}`}>
                      {p.phantomDiscrepancy! > 0 ? 'Overstated' : 'Missing'}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="rounded-xl border border-white/5 bg-ps-card p-5">
        <h3 className="text-sm font-bold text-white mb-4">Products by Category</h3>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
          {Array.from(categoryStats.entries()).map(([cat, stat]) => (
            <div key={cat} className="rounded-lg border border-white/5 bg-white/[0.02] p-3">
              <p className="truncate text-xs font-medium text-slate-300" title={cat}>{cat}</p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-sm font-bold text-white">{stat.count}</span>
                {stat.highRisk > 0 && (
                  <span className="text-xs font-medium text-ps-risk-high">{stat.highRisk} high</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
