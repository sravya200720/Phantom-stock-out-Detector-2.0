import { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, ChevronLeft, ChevronRight } from 'lucide-react';
import type { ProductWithMetrics, RiskLevel } from '@/types';
import { CATEGORIES } from '@/data/products';
import { formatINR } from '@/lib/inventory';
import { RiskBadge } from './RiskBadge';

interface CatalogProps {
  products: ProductWithMetrics[];
  onSelectProduct: (sku: string) => void;
}

const PAGE_SIZE = 12;

type SortKey = 'price-asc' | 'price-desc' | 'stock-asc' | 'stock-desc' | 'risk-desc' | 'name-asc';

const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: 'name-asc', label: 'Name (A-Z)' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'stock-asc', label: 'Stock: Low to High' },
  { value: 'stock-desc', label: 'Stock: High to Low' },
  { value: 'risk-desc', label: 'Highest Risk First' },
];

const RISK_FILTERS: { value: RiskLevel | 'all'; label: string }[] = [
  { value: 'all', label: 'All Risk Levels' },
  { value: 'high', label: 'High Risk' },
  { value: 'medium', label: 'Medium Risk' },
  { value: 'low', label: 'Low Risk' },
];

export function Catalog({ products, onSelectProduct }: CatalogProps) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('all');
  const [riskFilter, setRiskFilter] = useState<RiskLevel | 'all'>('all');
  const [sort, setSort] = useState<SortKey>('name-asc');
  const [page, setPage] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const filtered = useMemo(() => {
    let result = products;

    // Search
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q),
      );
    }

    // Category filter
    if (category !== 'all') {
      result = result.filter((p) => p.category === category);
    }

    // Risk filter
    if (riskFilter !== 'all') {
      result = result.filter((p) => p.stockOutRisk === riskFilter);
    }

    // Sort
    const sorted = [...result];
    switch (sort) {
      case 'price-asc': sorted.sort((a, b) => a.price - b.price); break;
      case 'price-desc': sorted.sort((a, b) => b.price - a.price); break;
      case 'stock-asc': sorted.sort((a, b) => a.recordedStock - b.recordedStock); break;
      case 'stock-desc': sorted.sort((a, b) => b.recordedStock - a.recordedStock); break;
      case 'risk-desc': sorted.sort((a, b) => b.riskScore - a.riskScore); break;
      case 'name-asc': sorted.sort((a, b) => a.name.localeCompare(b.name)); break;
    }
    return sorted;
  }, [products, search, category, riskFilter, sort]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const currentPage = Math.min(page, Math.max(0, totalPages - 1));
  const pageItems = filtered.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);

  const hasFilters = category !== 'all' || riskFilter !== 'all' || search.trim() !== '';

  const clearFilters = () => {
    setSearch('');
    setCategory('all');
    setRiskFilter('all');
    setSort('name-asc');
    setPage(0);
  };

  return (
    <div className="space-y-5 fade-in">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Product Catalog</h2>
          <p className="mt-1 text-sm text-slate-400">
            {filtered.length} of {products.length} products
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 rounded-lg border border-white/10 bg-ps-card px-4 py-2 text-sm font-medium text-slate-300 transition-colors hover:border-ps-cyan/30 hover:text-ps-cyan lg:hidden"
        >
          <SlidersHorizontal className="h-4 w-4" />
          Filters
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(0); }}
          placeholder="Search by product name, brand, or SKU..."
          className="w-full rounded-lg border border-white/10 bg-ps-card py-3 pl-11 pr-4 text-sm text-slate-200 placeholder-slate-500 outline-none transition-colors focus:border-ps-cyan/50"
        />
      </div>

      {/* Filters */}
      <div className={`${showFilters ? 'block' : 'hidden'} lg:block`}>
        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
          {/* Category */}
          <div className="flex-1 min-w-[180px]">
            <label className="mb-1.5 block text-xs font-medium text-slate-500">Category</label>
            <select
              value={category}
              onChange={(e) => { setCategory(e.target.value); setPage(0); }}
              className="w-full rounded-lg border border-white/10 bg-ps-card px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-ps-cyan/50"
            >
              <option value="all">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Risk */}
          <div className="flex-1 min-w-[150px]">
            <label className="mb-1.5 block text-xs font-medium text-slate-500">Stock Risk</label>
            <select
              value={riskFilter}
              onChange={(e) => { setRiskFilter(e.target.value as RiskLevel | 'all'); setPage(0); }}
              className="w-full rounded-lg border border-white/10 bg-ps-card px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-ps-cyan/50"
            >
              {RISK_FILTERS.map((r) => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>

          {/* Sort */}
          <div className="flex-1 min-w-[180px]">
            <label className="mb-1.5 block text-xs font-medium text-slate-500">Sort By</label>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="w-full rounded-lg border border-white/10 bg-ps-card px-3 py-2.5 text-sm text-slate-200 outline-none focus:border-ps-cyan/50"
            >
              {SORT_OPTIONS.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>

          {hasFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2.5 text-sm text-slate-400 transition-colors hover:border-ps-risk-high/30 hover:text-ps-risk-high"
            >
              <X className="h-4 w-4" /> Clear
            </button>
          )}
        </div>
      </div>

      {/* Product Grid */}
      {pageItems.length === 0 ? (
        <div className="rounded-xl border border-white/5 bg-ps-card py-20 text-center">
          <p className="text-slate-400">No products match your filters.</p>
          <button onClick={clearFilters} className="mt-3 text-sm text-ps-cyan hover:underline">
            Clear all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {pageItems.map((p) => (
            <button
              key={p.sku}
              onClick={() => onSelectProduct(p.sku)}
              className="group flex flex-col overflow-hidden rounded-xl border border-white/5 bg-ps-card text-left transition-all duration-200 hover:border-ps-cyan/30 hover:shadow-lg hover:shadow-ps-cyan/5"
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden bg-white/5">
                <img
                  src={p.image}
                  alt={p.name}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute top-2 right-2">
                  <RiskBadge risk={p.stockOutRisk} />
                </div>
              </div>

              {/* Info */}
              <div className="flex flex-1 flex-col p-3">
                <p className="text-[10px] font-medium uppercase tracking-wide text-slate-500">{p.brand}</p>
                <h3 className="mt-0.5 line-clamp-2 text-sm font-semibold leading-snug text-slate-200 group-hover:text-white">
                  {p.name}
                </h3>
                <p className="mt-1 text-xs text-slate-500">{p.packageSize} · {p.category}</p>

                <div className="mt-auto flex items-center justify-between pt-3">
                  <span className="text-base font-bold text-ps-cyan">{formatINR(p.price)}</span>
                  <span className={`text-xs font-medium ${p.recordedStock <= 0 ? 'text-ps-risk-high' : p.recordedStock < 20 ? 'text-ps-risk-medium' : 'text-slate-400'}`}>
                    Stock: {p.recordedStock}
                  </span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2 pt-2">
          <button
            onClick={() => setPage(Math.max(0, currentPage - 1))}
            disabled={currentPage === 0}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-slate-400 transition-colors hover:border-ps-cyan/30 hover:text-ps-cyan disabled:opacity-30 disabled:hover:border-white/10 disabled:hover:text-slate-400"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i)}
              className={`flex h-9 min-w-9 items-center justify-center rounded-lg border px-2 text-sm font-medium transition-colors ${
                i === currentPage
                  ? 'border-ps-cyan/30 bg-ps-cyan/10 text-ps-cyan'
                  : 'border-white/10 text-slate-400 hover:border-white/20 hover:text-slate-200'
              }`}
            >
              {i + 1}
            </button>
          ))}
          <button
            onClick={() => setPage(Math.min(totalPages - 1, currentPage + 1))}
            disabled={currentPage >= totalPages - 1}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-slate-400 transition-colors hover:border-ps-cyan/30 hover:text-ps-cyan disabled:opacity-30 disabled:hover:border-white/10 disabled:hover:text-slate-400"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
