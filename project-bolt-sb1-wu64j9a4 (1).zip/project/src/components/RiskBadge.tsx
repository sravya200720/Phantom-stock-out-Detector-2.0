import type { RiskLevel } from '@/types';

const RISK_CONFIG: Record<RiskLevel, { label: string; bg: string; text: string; glow: string }> = {
  high: { label: 'High Risk', bg: 'bg-ps-risk-high/15', text: 'text-ps-risk-high', glow: 'glow-high' },
  medium: { label: 'Medium Risk', bg: 'bg-ps-risk-medium/15', text: 'text-ps-risk-medium', glow: 'glow-medium' },
  low: { label: 'Low Risk', bg: 'bg-ps-risk-low/15', text: 'text-ps-risk-low', glow: 'glow-low' },
};

export function RiskBadge({ risk, size = 'sm' }: { risk: RiskLevel; size?: 'sm' | 'md' }) {
  const config = RISK_CONFIG[risk];
  const sizeClass = size === 'md' ? 'px-3 py-1.5 text-sm' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full ${config.bg} ${config.text} ${config.glow} ${sizeClass} font-semibold whitespace-nowrap`}
    >
      <span className={`h-1.5 w-1.5 rounded-full bg-current`} />
      {config.label}
    </span>
  );
}
