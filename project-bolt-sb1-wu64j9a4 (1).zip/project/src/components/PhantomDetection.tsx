import { useState, useMemo } from 'react';
import { Ghost, AlertTriangle, CheckCircle2, Info, ArrowRight } from 'lucide-react';
import type { ProductWithMetrics } from '@/types';
import { RiskBadge } from './RiskBadge';

interface PhantomDetectionProps {
  products: ProductWithMetrics[];
  onSelectProduct: (sku: string) => void;
}

type FilterKey = 'all' | 'discrepancy' | 'clean' | 'unverified';

export function PhantomDetection({ products, onSelectProduct }: PhantomDetectionProps) {
  const [filter, setFilter] = useState<FilterKey>('all');

  const stats = useMemo(() => {
    const verified = products.filter((p) => p.verifiedStock !== null);
    const discrepancies = verified.filter((p) => Math.abs(p.phantomDiscrepancy!) > 0);
    const clean = verified.filter((p) => p.phantomDiscrepancy === 0);
    const unverified = products.filter((p) => p.verifiedStock === null);
    return {
      verified: verified.length,
      discrepancies: discrepancies.length,
      clean: clean.length,
      unverified: unverified.length,
    };
  }, [products]);

  const filtered = useMemo(() => {
    switch (filter) {
      case 'discrepancy':
        return products.filter((p) => p.verifiedStock !== null && Math.abs(p.phantomDiscrepancy!) > 0);
      case 'clean':
        return products.filter((p) => p.verifiedStock !== null && p.phantomDiscrepancy === 0);
      case 'unverified':
        return products.filter((p) => p.verifiedStock === null);
      default:
        return products;
    }
  }, [products, filter]);

  const filterTabs: { key: FilterKey; label: string; count: number }[] = [
    { key: 'all', label: 'All Products', count: products.length },
    { key: 'discrepancy', label: 'Discrepancies Found', count: stats.discrepancies },
    { key: 'clean', label: 'Verified Clean', count: stats.clean },
    { key: 'unverified', label: 'Not Yet Audited', count: stats.unverified },
  ];

  return (
    <div className="space-y-5 fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Ghost className="h-6 w-6 text-ps-purple" />
          <h2 className="text-2xl font-bold text-white">Phantom Stock-Out Detection</h2>
        </div>
        <p className="mt-1 text-sm text-slate-400">
          Compares recorded system stock with independently verified physical stock to detect hidden discrepancies.
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-white/5 bg-ps-card p-4">
          <p className="text-xs text-slate-500">Verified Products</p>
          <p className="mt-1 text-2xl font-bold text-white">{stats.verified}</p>
        </div>
        <div className="rounded-xl border border-ps-risk-high/20 bg-ps-card p-4">
          <p className="text-xs text-slate-500">Discrepancies Found</p>
          <p className="mt-1 text-2xl font-bold text-ps-risk-high">{stats.discrepancies}</p>
        </div>
        <div className="rounded-xl border border-ps-risk-low/20 bg-ps-card p-4">
          <p className="text-xs text-slate-500">Verified Clean</p>
          <p className="mt-1 text-2xl font-bold text-ps-risk-low">{stats.clean}</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-ps-card p-4">
          <p className="text-xs text-slate-500">Not Yet Audited</p>
          <p className="mt-1 text-2xl font-bold text-slate-400">{stats.unverified}</p>
        </div>
      </div>

      {/* Info Banner */}
      <div className="flex items-start gap-3 rounded-lg border border-ps-cyan/20 bg-ps-cyan/5 p-4">
        <Info className="mt-0.5 h-5 w-5 flex-shrink-0 text-ps-cyan" />
        <p className="text-xs leading-relaxed text-slate-400">
          <span className="font-medium text-slate-300">How it works:</span> When both recorded stock (from the inventory system) and verified physical stock (from an independent audit) are available, the system compares the two. A discrepancy means the system's stock number does not match what is actually on the shelf — this is a phantom stock-out. Products without a physical audit are flagged as simulated data.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filterTabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-all ${
              filter === tab.key
                ? 'bg-ps-cyan/10 text-ps-cyan ring-1 ring-ps-cyan/20'
                : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200'
            }`}
          >
            {tab.label}
            <span className={`rounded-full px-1.5 py-0.5 text-xs ${
              filter === tab.key ? 'bg-ps-cyan/20' : 'bg-white/10'
            }`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Product List */}
      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-white/5 bg-ps-card py-16 text-center">
            <p className="text-slate-500">No products in this category.</p>
          </div>
        ) : (
          filtered.map((p) => {
            const isPhantom = p.verifiedStock !== null && Math.abs(p.phantomDiscrepancy!) > 0;
            const isClean = p.verifiedStock !== null && p.phantomDiscrepancy === 0;
            return (
              <button
                key={p.sku}
                onClick={() => onSelectProduct(p.sku)}
                className="group flex w-full items-center gap-4 rounded-xl border border-white/5 bg-ps-card p-3 text-left transition-all hover:border-ps-cyan/20"
              >
                <img src={p.image} alt={p.name} className="h-12 w-12 flex-shrink-0 rounded-lg object-cover" loading="lazy" />

                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-200 group-hover:text-white">{p.name}</p>
                  <p className="text-xs text-slate-500">{p.sku} · {p.category}</p>
                </div>

                {/* Stock Comparison */}
                <div className="hidden sm:flex items-center gap-3 text-xs">
                  <div className="text-center">
                    <p className="text-slate-500">Recorded</p>
                    <p className="font-bold text-slate-300">{p.recordedStock}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-slate-500">Verified</p>
                    <p className={`font-bold ${isPhantom ? 'text-ps-risk-high' : 'text-slate-300'}`}>
                      {p.verifiedStock !== null ? p.verifiedStock : '—'}
                    </p>
                  </div>
                  {isPhantom && (
                    <div className="text-center">
                      <p className="text-slate-500">Diff</p>
                      <p className={`font-bold ${p.phantomDiscrepancy! > 0 ? 'text-ps-risk-medium' : 'text-ps-risk-high'}`}>
                        {p.phantomDiscrepancy! > 0 ? '+' : ''}{p.phantomDiscrepancy}
                      </p>
                    </div>
                  )}
                </div>

                {/* Status */}
                <div className="flex-shrink-0">
                  {isPhantom ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-ps-risk-high/15 px-3 py-1.5 text-xs font-semibold text-ps-risk-high glow-high">
                      <AlertTriangle className="h-3.5 w-3.5" />
                      {p.phantomDiscrepancy! > 0 ? 'Overstated' : 'Missing Stock'}
                    </span>
                  ) : isClean ? (
                    <span className="flex items-center gap-1.5 rounded-full bg-ps-risk-low/15 px-3 py-1.5 text-xs font-semibold text-ps-risk-low">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Verified
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 rounded-full bg-ps-risk-medium/15 px-3 py-1.5 text-xs font-semibold text-ps-risk-medium">
                      <Info className="h-3.5 w-3.5" />
                      Simulated
                    </span>
                  )}
                </div>

                <ArrowRight className="h-4 w-4 flex-shrink-0 text-slate-600 transition-colors group-hover:text-ps-cyan" />
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
