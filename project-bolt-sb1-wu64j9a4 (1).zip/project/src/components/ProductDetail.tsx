import { ArrowLeft, Package, IndianRupee, TrendingUp, Clock, Truck, AlertTriangle, Brain, ClipboardCheck, Lightbulb, Boxes } from 'lucide-react';
import type { ProductWithMetrics } from '@/types';
import { formatINR } from '@/lib/inventory';
import { RiskBadge } from './RiskBadge';

interface ProductDetailProps {
  product: ProductWithMetrics;
  onBack: () => void;
}

export function ProductDetail({ product, onBack }: ProductDetailProps) {
  const isPhantom = product.phantomDiscrepancy !== null && Math.abs(product.phantomDiscrepancy) > 0;

  const stats = [
    { label: 'Retail Price', value: formatINR(product.price), sub: 'Illustrative', icon: IndianRupee },
    { label: 'Recorded Stock', value: product.recordedStock.toString(), sub: 'System count', icon: Package },
    { label: 'Verified Stock', value: product.verifiedStock !== null ? product.verifiedStock.toString() : 'Not audited', sub: product.verifiedStock !== null ? 'Physical count' : 'Simulated', icon: ClipboardCheck },
    { label: 'Daily Sales', value: product.dailySales.toString(), sub: 'Units/day', icon: TrendingUp },
    { label: 'Supplier Lead Time', value: `${product.supplierLeadTime} days`, sub: 'Restock time', icon: Truck },
    { label: 'Est. Stock-Out', value: product.estimatedStockOutDays !== null ? (product.estimatedStockOutDays === 0 ? 'Now' : `${product.estimatedStockOutDays} days`) : 'N/A', sub: 'At current rate', icon: Clock },
  ];

  return (
    <div className="space-y-5 fade-in">
      {/* Back button */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-sm font-medium text-slate-400 transition-colors hover:text-ps-cyan"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Catalog
      </button>

      {/* Main Info */}
      <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
        {/* Image */}
        <div className="relative overflow-hidden rounded-xl border border-white/5 bg-ps-card">
          <img src={product.image} alt={product.name} className="aspect-square w-full object-cover" />
          <div className="absolute top-3 right-3">
            <RiskBadge risk={product.stockOutRisk} size="md" />
          </div>
        </div>

        {/* Details */}
        <div className="space-y-5">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-ps-cyan">{product.brand}</p>
            <h2 className="mt-1 text-2xl font-bold text-white">{product.name}</h2>
            <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-slate-400">
              <span className="flex items-center gap-1"><Package className="h-3.5 w-3.5" /> {product.packageSize}</span>
              <span className="flex items-center gap-1"><Boxes className="h-3.5 w-3.5" /> {product.category}</span>
              <span className="rounded bg-white/5 px-2 py-0.5 font-mono text-xs text-slate-300">{product.sku}</span>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {stats.map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.label} className="rounded-lg border border-white/5 bg-ps-card p-3">
                  <Icon className="mb-2 h-4 w-4 text-slate-500" />
                  <p className="text-lg font-bold text-white">{s.value}</p>
                  <p className="text-[10px] text-slate-500">{s.label} · {s.sub}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Phantom Detection Section */}
      <div className="rounded-xl border border-white/5 bg-ps-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <ClipboardCheck className="h-5 w-5 text-ps-purple" />
          <h3 className="text-sm font-bold text-white">Phantom Stock-Out Detection</h3>
        </div>

        {product.verifiedStock === null ? (
          <div className="flex items-start gap-3 rounded-lg border border-ps-risk-medium/20 bg-ps-risk-medium/5 p-4">
            <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-ps-risk-medium" />
            <div>
              <p className="text-sm font-medium text-slate-200">No physical audit conducted</p>
              <p className="mt-1 text-xs text-slate-400">
                Verified physical stock is not available for this product. The recorded stock is simulated data and has not been independently verified. An audit is recommended to rule out phantom discrepancies.
              </p>
            </div>
          </div>
        ) : isPhantom ? (
          <div className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border border-ps-risk-high/20 bg-ps-risk-high/5 p-4">
              <AlertTriangle className="mt-0.5 h-5 w-5 flex-shrink-0 text-ps-risk-high" />
              <div>
                <p className="text-sm font-medium text-ps-risk-high">Discrepancy Detected</p>
                <p className="mt-1 text-xs text-slate-400">
                  Recorded stock shows <span className="font-bold text-slate-200">{product.recordedStock}</span> units but verified physical count found <span className="font-bold text-slate-200">{product.verifiedStock}</span> units.
                  {' '}
                  {product.phantomDiscrepancy! > 0
                    ? `The system overstates stock by ${product.phantomDiscrepancy} units — these units may have been lost, stolen, or damaged without being recorded.`
                    : `The system understates stock by ${Math.abs(product.phantomDiscrepancy!)} units — recent deliveries may not have been logged in the system.`}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3 text-center">
                <p className="text-xs text-slate-500">Recorded</p>
                <p className="text-xl font-bold text-slate-200">{product.recordedStock}</p>
              </div>
              <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3 text-center">
                <p className="text-xs text-slate-500">Verified</p>
                <p className="text-xl font-bold text-ps-cyan">{product.verifiedStock}</p>
              </div>
              <div className="rounded-lg border border-white/5 bg-white/[0.02] p-3 text-center">
                <p className="text-xs text-slate-500">Discrepancy</p>
                <p className={`text-xl font-bold ${product.phantomDiscrepancy! > 0 ? 'text-ps-risk-medium' : 'text-ps-risk-high'}`}>
                  {product.phantomDiscrepancy! > 0 ? '+' : ''}{product.phantomDiscrepancy}
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-3 rounded-lg border border-ps-risk-low/20 bg-ps-risk-low/5 p-4">
            <ClipboardCheck className="mt-0.5 h-5 w-5 flex-shrink-0 text-ps-risk-low" />
            <div>
              <p className="text-sm font-medium text-ps-risk-low">No Discrepancy</p>
              <p className="mt-1 text-xs text-slate-400">
                Verified physical stock matches the recorded system stock. No phantom stock-out detected for this product.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* AI Prediction Section */}
      <div className="rounded-xl border border-white/5 bg-ps-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Brain className="h-5 w-5 text-ps-cyan" />
          <h3 className="text-sm font-bold text-white">AI Stock-Out Risk Prediction</h3>
          <span className="ml-auto text-[10px] text-slate-500">Heuristic model · not a trained ML model</span>
        </div>

        {/* Risk Score Bar */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-medium text-slate-400">Risk Score</span>
            <span className={`text-sm font-bold ${
              product.stockOutRisk === 'high' ? 'text-ps-risk-high' :
              product.stockOutRisk === 'medium' ? 'text-ps-risk-medium' : 'text-ps-risk-low'
            }`}>
              {product.riskScore}/100
            </span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                product.stockOutRisk === 'high' ? 'bg-ps-risk-high' :
                product.stockOutRisk === 'medium' ? 'bg-ps-risk-medium' : 'bg-ps-risk-low'
              }`}
              style={{ width: `${product.riskScore}%` }}
            />
          </div>
        </div>

        {/* Explanation */}
        <div className="rounded-lg border border-white/5 bg-white/[0.02] p-4">
          <p className="text-xs font-medium text-slate-300 mb-2">Risk Explanation</p>
          <p className="text-sm leading-relaxed text-slate-400">{product.riskExplanation}</p>
        </div>

        {/* Reorder & Action */}
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="rounded-lg border border-white/5 bg-white/[0.02] p-4">
            <div className="flex items-center gap-2 mb-1">
              <Boxes className="h-4 w-4 text-ps-cyan" />
              <p className="text-xs font-medium text-slate-300">Recommended Reorder</p>
            </div>
            <p className="text-2xl font-bold text-white">{product.reorderQuantity} <span className="text-sm font-normal text-slate-500">units</span></p>
          </div>
          <div className="rounded-lg border border-white/5 bg-white/[0.02] p-4">
            <div className="flex items-center gap-2 mb-1">
              <Lightbulb className="h-4 w-4 text-ps-purple" />
              <p className="text-xs font-medium text-slate-300">Recommended Action</p>
            </div>
            <p className="text-sm leading-snug text-slate-300">{product.recommendedAction}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
