import { Radar, LayoutDashboard, Package, Ghost, BrainCircuit, X } from 'lucide-react';
import type { View } from '@/types';

interface SidebarProps {
  currentView: View;
  onNavigate: (view: View) => void;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: { id: View; label: string; icon: typeof Radar }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'catalog', label: 'Product Catalog', icon: Package },
  { id: 'phantom', label: 'Phantom Detection', icon: Ghost },
  { id: 'predictions', label: 'AI Predictions', icon: BrainCircuit },
];

export function Sidebar({ currentView, onNavigate, isMobileOpen, onCloseMobile }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed lg:sticky top-0 z-40 h-screen w-72 flex-shrink-0 transform transition-transform duration-300 lg:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-full flex-col bg-ps-sidebar border-r border-white/5">
          {/* Logo / Title */}
          <div className="relative px-6 pt-8 pb-6 border-b border-white/5">
            <div className="flex items-start gap-3">
              <div className="mt-1 flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-ps-cyan/20 to-ps-purple/20 ring-1 ring-ps-cyan/30">
                <Radar className="h-6 w-6 text-ps-cyan" />
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-black leading-[1.1] tracking-tight text-white">
                  PHANTOM
                </h1>
                <h1 className="text-2xl font-black leading-[1.1] tracking-tight text-white">
                  STOCK-OUT
                </h1>
                <h1 className="text-2xl font-black leading-[1.1] tracking-tight text-ps-cyan">
                  DETECTOR 2.0
                </h1>
              </div>
              <button
                onClick={onCloseMobile}
                className="lg:hidden text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-4 text-xs font-medium leading-relaxed text-slate-500">
              Predictive Inventory Intelligence with Explainable AI
            </p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto px-4 py-6">
            <p className="px-3 mb-3 text-[10px] font-bold uppercase tracking-wider text-slate-600">
              Navigation
            </p>
            <ul className="space-y-1">
              {NAV_ITEMS.map((item) => {
                const isActive = currentView === item.id || (item.id === 'catalog' && currentView === 'product-detail');
                const Icon = item.icon;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => onNavigate(item.id)}
                      className={`group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
                        isActive
                          ? 'bg-gradient-to-r from-ps-cyan/10 to-transparent text-ps-cyan ring-1 ring-ps-cyan/20'
                          : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                      }`}
                    >
                      <Icon
                        className={`h-5 w-5 flex-shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-ps-cyan' : ''
                        }`}
                      />
                      {item.label}
                    </button>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-white/5">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <div className="h-2 w-2 rounded-full bg-ps-risk-low animate-pulse" />
              <span>System Active</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
