import { useState, useMemo } from 'react';
import { Brain, TrendingDown, AlertTriangle, ArrowRight, Info, Clock, Boxes } from 'lucide-react';
import type { ProductWithMetrics, RiskLevel } from '@/types';
import { RiskBadge } from './RiskBadge';
import { formatINR } from '@/lib/inventory';

interface PredictionsProps {
  products: ProductWithMetrics[];
  onSelectProduct: (sku: string) => void;
}

type SortKey = 'risk-desc' | 'stockout-asc' | 'reorder-desc';

export function Predictions({ products, onSelectProduct }: PredictionsProps) {
  const [riskFilter, setRiskFilter] = useState<RiskLevel | 'all'>('all');
  const [sort, setSort] = useState<SortKey>('risk-desc');

  const stats = useMemo(() => {
    const high = products.filter((p) => p.stockOutRisk === 'high').length;
    const medium = products.filter((p) => p.stockOutRisk === 'medium').length;
    const low = products.filter((p) => p.stockOutRisk === 'low').length;
    const stockOutSoon = products.filter(
      (p) => p.estimatedStockOutDays !== null && p.estimatedStockOutDays <= p.supplierLeadTime,
    ).length;
    const totalReorder = products.reduce((sum, p) => sum + p.reorderQuantity, 0);
    return { high, medium, low, stockOutSoon, totalReorder };
  }, [products]);

  const filtered = useMemo(() => {
    let result = products;
    if (riskFilter !== 'all') {
      result = result.filter((p) => p.stockOutRisk === riskFilter);
    }
    const sorted = [...result];
    switch (sort) {
      case 'risk-desc': sorted.sort((a, b) => b.riskScore - a.riskScore); break;
      case 'stockout-asc':
        sorted.sort((a, b) => {
          const aDays = a.estimatedStockOutDays ?? 9999;
          const bDays = b.estimatedStockOutDays ?? 9999;
          return aDays - bDays;
        });
        break;
      case 'reorder-desc': sorted.sort((a, b) => b.reorderQuantity - a.reorderQuantity); break;
    }
    return sorted;
  }, [products, riskFilter, sort]);

  return (
    <div className="space-y-5 fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <Brain className="h-6 w-6 text-ps-cyan" />
          <h2 className="text-2xl font-bold text-white">AI Stock-Out Predictions</h2>
        </div>
        <p className="mt-1 text-sm text-slate-400">
          Risk scores calculated from stock levels, daily sales velocity, and supplier lead time.
        </p>
      </div>

      {/* Disclaimer */}
      <div className="flex items-start gap-3 rounded-lg border border-ps-risk-medium/20 bg-ps-risk-medium/5 p-4">
        <Info className="mt-0.5 h-5 w-5 flex-shrink-0 text-ps-risk-medium" />
        <p className="text-xs leading-relaxed text-slate-400">
          <span className="font-medium text-slate-300">Note:</span> Stock-out risk is computed using a transparent heuristic model based on days-of-stock remaining versus supplier lead time. This is not a trained machine learning model, and no live database connection is used. Prices are illustrative and not verified against current retail listings.
        </p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <div className="rounded-xl border border-ps-risk-high/20 bg-ps-card p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-ps-risk-high" />
            <p className="text-xs text-slate-500">High Risk</p>
          </div>
          <p className="mt-2 text-2xl font-bold text-ps-risk-high">{stats.high}</p>
        </div>
        <div className="rounded-xl border border-ps-risk-medium/20 bg-ps-card p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-ps-risk-medium" />
            <p className="text-xs text-slate-500">Medium Risk</p>
          </div>
          <p className="mt-2 text-2xl font-bold text-ps-risk-medium">{stats.medium}</p>
        </div>
        <div className="rounded-xl border border-ps-risk-low/20 bg-ps-card p-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-ps-risk-low" />
            <p className="text-xs text-slate-500">Low Risk</p>
          </div>
          <p className="mt-2 text-2xl font-bold text-ps-risk-low">{stats.low}</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-ps-card p-4">
          <div className="flex items-center gap-2">
            <TrendingDown className="h-4 w-4 text-ps-cyan" />
            <p className="text-xs text-slate-500">Stock-Out Soon</p>
          </div>
          <p className="mt-2 text-2xl font-bold text-white">{stats.stockOutSoon}</p>
        </div>
        <div className="rounded-xl border border-white/5 bg-ps-card p-4">
          <div className="flex items-center gap-2">
            <Boxes className="h-4 w-4 text-ps-purple" />
            <p className="text-xs text-slate-500">Total Reorder Qty</p>
          </div>
          <p className="mt-2 text-2xl font-bold text-white">{stats.totalReorder}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-2">
          {(['all', 'high', 'medium', 'low'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setRiskFilter(r)}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition-all ${
                riskFilter === r
                  ? 'bg-ps-cyan/10 text-ps-cyan ring-1 ring-ps-cyan/20'
                  : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-slate-200'
              }`}
            >
              {r === 'all' ? 'All Risk' : r.charAt(0).toUpperCase() + r.slice(1) + ' Risk'}
            </button>
          ))}
        </div>
        <select
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
          className="rounded-lg border border-white/10 bg-ps-card px-3 py-2 text-sm text-slate-200 outline-none focus:border-ps-cyan/50"
        >
          <option value="risk-desc">Highest Risk First</option>
          <option value="stockout-asc">Soonest Stock-Out First</option>
          <option value="reorder-desc">Largest Reorder First</option>
        </select>
      </div>

      {/* Prediction Cards */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="rounded-xl border border-white/5 bg-ps-card py-16 text-center">
            <p className="text-slate-500">No products match this filter.</p>
          </div>
        ) : (
          filtered.map((p) => (
            <button
              key={p.sku}
              onClick={() => onSelectProduct(p.sku)}
              className="group w-full overflow-hidden rounded-xl border border-white/5 bg-ps-card p-4 text-left transition-all hover:border-ps-cyan/20"
            >
              <div className="flex items-start gap-4">
                <img src={p.image} alt={p.name} className="h-14 w-14 flex-shrink-0 rounded-lg object-cover" loading="lazy" />

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-slate-200 group-hover:text-white">{p.name}</p>
                      <p className="text-xs text-slate-500">{p.sku} · {p.brand} · {p.category}</p>
                    </div>
                    <RiskBadge risk={p.stockOutRisk} />
                  </div>

                  {/* Risk Score Bar */}
                  <div className="mt-3 flex items-center gap-3">
                    <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/5">
                      <div
                        className={`h-full rounded-full ${
                          p.stockOutRisk === 'high' ? 'bg-ps-risk-high' :
                          p.stockOutRisk === 'medium' ? 'bg-ps-risk-medium' : 'bg-ps-risk-low'
                        }`}
                        style={{ width: `${p.riskScore}%` }}
                      />
                    </div>
                    <span className={`text-xs font-bold ${
                      p.stockOutRisk === 'high' ? 'text-ps-risk-high' :
                      p.stockOutRisk === 'medium' ? 'text-ps-risk-medium' : 'text-ps-risk-low'
                    }`}>
                      {p.riskScore}/100
                    </span>
                  </div>

                  {/* Metrics Row */}
                  <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                    <div>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <Boxes className="h-3 w-3" /> Stock
                      </p>
                      <p className={`text-sm font-bold ${p.recordedStock <= 0 ? 'text-ps-risk-high' : 'text-slate-300'}`}>
                        {p.recordedStock}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <TrendingDown className="h-3 w-3" /> Sales/day
                      </p>
                      <p className="text-sm font-bold text-slate-300">{p.dailySales}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <Clock className="h-3 w-3" /> Stock-Out
                      </p>
                      <p className={`text-sm font-bold ${
                        p.estimatedStockOutDays !== null && p.estimatedStockOutDays <= p.supplierLeadTime
                          ? 'text-ps-risk-high' : 'text-slate-300'
                      }`}>
                        {p.estimatedStockOutDays === null ? 'N/A' : p.estimatedStockOutDays === 0 ? 'Now' : `${p.estimatedStockOutDays}d`}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-500 flex items-center gap-1">
                        <ArrowRight className="h-3 w-3" /> Reorder
                      </p>
                      <p className="text-sm font-bold text-ps-cyan">{p.reorderQuantity} units</p>
                    </div>
                  </div>

                  {/* Explanation */}
                  <p className="mt-3 text-xs leading-relaxed text-slate-500 line-clamp-2">
                    {p.riskExplanation}
                  </p>
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
