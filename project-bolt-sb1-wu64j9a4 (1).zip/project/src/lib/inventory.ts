import type { Product, ProductWithMetrics, RiskLevel, DashboardMetrics } from '@/types';

const SAFETY_STOCK_DAYS = 3;

export function calculateRiskScore(product: Product): number {
  const { recordedStock, dailySales, supplierLeadTime } = product;
  if (dailySales <= 0) return 15;

  const daysOfStock = recordedStock / dailySales;
  const leadTimeCoverage = supplierLeadTime;

  // Risk increases as days of stock decrease relative to lead time
  // 100 when already stocked out, lower as buffer grows
  if (recordedStock <= 0) return 100;
  if (daysOfStock <= leadTimeCoverage) {
    // Within danger zone — will run out before or during resupply
    const ratio = daysOfStock / leadTimeCoverage;
    return Math.round(70 + 30 * (1 - ratio));
  }
  // Has buffer beyond lead time
  const bufferDays = daysOfStock - leadTimeCoverage;
  const score = Math.max(5, 70 - bufferDays * 8);
  return Math.round(score);
}

export function classifyRisk(score: number): RiskLevel {
  if (score >= 70) return 'high';
  if (score >= 40) return 'medium';
  return 'low';
}

export function estimateStockOutDays(product: Product): number | null {
  if (product.dailySales <= 0) return null;
  if (product.recordedStock <= 0) return 0;
  return Math.round(product.recordedStock / product.dailySales);
}

export function calculateReorderQuantity(product: Product): number {
  const { dailySales, supplierLeadTime } = product;
  const targetStockDays = supplierLeadTime + SAFETY_STOCK_DAYS;
  const targetStock = Math.ceil(dailySales * targetStockDays);
  const needed = targetStock - product.recordedStock;
  return Math.max(0, needed);
}

export function buildRiskExplanation(
  product: Product,
  risk: RiskLevel,
  stockOutDays: number | null,
  reorderQty: number,
): string {
  const { recordedStock, dailySales, supplierLeadTime } = product;
  const parts: string[] = [];

  if (recordedStock <= 0) {
    parts.push('Recorded stock is zero — the product is already stocked out.');
  } else {
    parts.push(`Recorded stock is ${recordedStock} units, selling ~${dailySales} units/day.`);
  }

  if (stockOutDays !== null) {
    if (stockOutDays <= 0) {
      parts.push('Stock-out is occurring now.');
    } else if (stockOutDays <= supplierLeadTime) {
      parts.push(
        `Estimated stock-out in ~${stockOutDays} day(s), which is before the supplier lead time of ${supplierLeadTime} days — resupply will arrive too late.`,
      );
    } else {
      parts.push(`Estimated stock-out in ~${stockOutDays} days (supplier lead time is ${supplierLeadTime} days).`);
    }
  }

  if (risk === 'high') {
    parts.push('High risk: immediate reorder recommended.');
  } else if (risk === 'medium') {
    parts.push('Medium risk: monitor closely and prepare to reorder.');
  } else {
    parts.push('Low risk: stock levels are healthy for now.');
  }

  if (reorderQty > 0) {
    parts.push(`Suggested reorder quantity: ${reorderQty} units to cover ${supplierLeadTime + SAFETY_STOCK_DAYS} days of demand plus safety stock.`);
  } else {
    parts.push('No reorder needed at current demand levels.');
  }

  return parts.join(' ');
}

export function recommendAction(
  risk: RiskLevel,
  phantom: number | null,
  reorderQty: number,
): string {
  if (phantom !== null && Math.abs(phantom) > 0) {
    return 'Investigate phantom discrepancy — physical audit recommended before reordering.';
  }
  if (risk === 'high') {
    return reorderQty > 0
      ? `Place urgent reorder of ${reorderQty} units.`
      : 'Review stock immediately — possible data entry error.';
  }
  if (risk === 'medium') {
    return reorderQty > 0
      ? `Prepare reorder of ${reorderQty} units within 1–2 days.`
      : 'Monitor stock levels daily.';
  }
  return 'No action needed — maintain normal restocking cycle.';
}

export function enrichProduct(product: Product): ProductWithMetrics {
  const riskScore = calculateRiskScore(product);
  const stockOutRisk = classifyRisk(riskScore);
  const estimatedStockOutDays = estimateStockOutDays(product);
  const reorderQuantity = calculateReorderQuantity(product);

  const phantomDiscrepancy =
    product.verifiedStock !== null
      ? product.recordedStock - product.verifiedStock
      : null;

  const recommendedAction = recommendAction(stockOutRisk, phantomDiscrepancy, reorderQuantity);
  const riskExplanation = buildRiskExplanation(product, stockOutRisk, estimatedStockOutDays, reorderQuantity);

  return {
    ...product,
    riskScore,
    stockOutRisk,
    phantomDiscrepancy,
    estimatedStockOutDays,
    recommendedAction,
    reorderQuantity,
    riskExplanation,
  };
}

export function computeDashboardMetrics(
  products: ProductWithMetrics[],
): DashboardMetrics {
  return {
    totalProducts: products.length,
    totalCategories: new Set(products.map((p) => p.category)).size,
    totalInventoryValue: products.reduce(
      (sum, p) => sum + p.recordedStock * p.price,
      0,
    ),
    highRiskCount: products.filter((p) => p.stockOutRisk === 'high').length,
    suspectedPhantomCount: products.filter(
      (p) => p.phantomDiscrepancy !== null && Math.abs(p.phantomDiscrepancy) > 0,
    ).length,
    predictedStockOuts: products.filter(
      (p) =>
        p.estimatedStockOutDays !== null &&
        p.estimatedStockOutDays <= p.supplierLeadTime,
    ).length,
  };
}

export function formatINR(amount: number): string {
  return '₹' + amount.toLocaleString('en-IN');
}
