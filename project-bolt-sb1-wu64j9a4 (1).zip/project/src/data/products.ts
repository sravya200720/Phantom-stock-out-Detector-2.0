import type { Product } from '@/types';

export const CATEGORIES: string[] = [
  'Milk',
  'Dairy Products',
  'Bread & Bakery',
  'Biscuits & Cookies',
  'Chocolates & Candies',
  'Chips & Snacks',
  'Instant Noodles',
  'Soft Drinks',
  'Juices & Energy Drinks',
  'Tea & Coffee',
  'Rice',
  'Wheat Flour & Atta',
  'Pulses & Lentils',
  'Cooking Oils',
  'Salt & Sugar',
  'Spices & Masalas',
  'Breakfast Cereals',
  'Frozen Foods',
  'Ice Cream',
  'Packaged Foods',
  'Personal Care',
  'Oral Care',
  'Hair Care',
  'Skin Care',
  'Laundry Products',
  'Home Cleaning',
  'Dishwashing Products',
  'Baby Care',
  'Pet Care',
  'Household Essentials',
];

export const PRODUCTS: Product[] = [
  // === Milk (4) ===
  { sku: 'MILK-001', name: 'Amul Taaza Toned Milk', brand: 'Amul', image: 'https://images.pexels.com/photos/36183642/pexels-photo-36183642.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 ml', price: 28, category: 'Milk', recordedStock: 120, verifiedStock: 118, dailySales: 35, supplierLeadTime: 1 },
  { sku: 'MILK-002', name: 'Mother Dairy Full Cream Milk', brand: 'Mother Dairy', image: 'https://images.pexels.com/photos/18258533/pexels-photo-18258533.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 66, category: 'Milk', recordedStock: 60, verifiedStock: 60, dailySales: 22, supplierLeadTime: 1 },
  { sku: 'MILK-003', name: 'Amul Gold Full Cream Milk', brand: 'Amul', image: 'https://images.pexels.com/photos/5967316/pexels-photo-5967316.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 ml', price: 35, category: 'Milk', recordedStock: 15, verifiedStock: null, dailySales: 28, supplierLeadTime: 1 },
  { sku: 'MILK-004', name: 'Heritage Cow Milk', brand: 'Heritage', image: 'https://images.pexels.com/photos/37304947/pexels-photo-37304947.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 60, category: 'Milk', recordedStock: 0, verifiedStock: null, dailySales: 18, supplierLeadTime: 2 },

  // === Dairy Products (3) ===
  { sku: 'DRY-001', name: 'Amul Butter Salted', brand: 'Amul', image: 'https://images.pexels.com/photos/11098743/pexels-photo-11098743.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 56, category: 'Dairy Products', recordedStock: 45, verifiedStock: 45, dailySales: 12, supplierLeadTime: 3 },
  { sku: 'DRY-002', name: 'Amul Cheese Slices', brand: 'Amul', image: 'https://images.pexels.com/photos/34406230/pexels-photo-34406230.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 g', price: 135, category: 'Dairy Products', recordedStock: 20, verifiedStock: 17, dailySales: 8, supplierLeadTime: 4 },
  { sku: 'DRY-003', name: 'Nestle Yogurt Plain', brand: 'Nestle', image: 'https://images.pexels.com/photos/32214637/pexels-photo-32214637.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '90 g', price: 25, category: 'Dairy Products', recordedStock: 80, verifiedStock: null, dailySales: 15, supplierLeadTime: 2 },

  // === Bread & Bakery (3) ===
  { sku: 'BRE-001', name: 'Britannia White Bread', brand: 'Britannia', image: 'https://images.pexels.com/photos/18647862/pexels-photo-18647862.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 g', price: 40, category: 'Bread & Bakery', recordedStock: 30, verifiedStock: 28, dailySales: 25, supplierLeadTime: 1 },
  { sku: 'BRE-002', name: 'Modern Multigrain Bread', brand: 'Modern', image: 'https://images.pexels.com/photos/5567093/pexels-photo-5567093.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 g', price: 50, category: 'Bread & Bakery', recordedStock: 10, verifiedStock: null, dailySales: 20, supplierLeadTime: 1 },
  { sku: 'BRE-003', name: 'Britannia Pav Bun', brand: 'Britannia', image: 'https://images.pexels.com/photos/2680601/pexels-photo-2680601.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '6 pcs', price: 35, category: 'Bread & Bakery', recordedStock: 50, verifiedStock: 50, dailySales: 18, supplierLeadTime: 1 },

  // === Biscuits & Cookies (4) ===
  { sku: 'BIS-001', name: 'Parle-G Glucose Biscuits', brand: 'Parle', image: 'https://images.pexels.com/photos/37817590/pexels-photo-37817590.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 10, category: 'Biscuits & Cookies', recordedStock: 200, verifiedStock: 195, dailySales: 60, supplierLeadTime: 3 },
  { sku: 'BIS-002', name: 'Britannia Marie Gold', brand: 'Britannia', image: 'https://images.pexels.com/photos/5599465/pexels-photo-5599465.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '250 g', price: 35, category: 'Biscuits & Cookies', recordedStock: 80, verifiedStock: null, dailySales: 30, supplierLeadTime: 3 },
  { sku: 'BIS-003', name: 'Oreo Cream Biscuit', brand: 'Cadbury', image: 'https://images.pexels.com/photos/25401697/pexels-photo-25401697.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '120 g', price: 40, category: 'Biscuits & Cookies', recordedStock: 12, verifiedStock: 10, dailySales: 45, supplierLeadTime: 4 },
  { sku: 'BIS-004', name: 'Hide & Seek Chocolate Chip', brand: 'Parle', image: 'https://images.pexels.com/photos/37304947/pexels-photo-37304947.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 30, category: 'Biscuits & Cookies', recordedStock: 40, verifiedStock: null, dailySales: 25, supplierLeadTime: 3 },

  // === Chocolates & Candies (4) ===
  { sku: 'CHC-001', name: 'Dairy Milk Silk Chocolate', brand: 'Cadbury', image: 'https://images.pexels.com/photos/37857736/pexels-photo-37857736.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '150 g', price: 175, category: 'Chocolates & Candies', recordedStock: 35, verifiedStock: 33, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'CHC-002', name: 'Kit Kat Wafer Chocolate', brand: 'Nestle', image: 'https://images.pexels.com/photos/31899749/pexels-photo-31899749.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '37 g', price: 35, category: 'Chocolates & Candies', recordedStock: 100, verifiedStock: null, dailySales: 40, supplierLeadTime: 4 },
  { sku: 'CHC-003', name: '5 Star Chocolate Bar', brand: 'Cadbury', image: 'https://images.pexels.com/photos/13898315/pexels-photo-13898315.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '40 g', price: 15, category: 'Chocolates & Candies', recordedStock: 8, verifiedStock: 8, dailySales: 35, supplierLeadTime: 4 },
  { sku: 'CHC-004', name: 'M&M Peanut Chocolates', brand: 'Mars', image: 'https://images.pexels.com/photos/31443060/pexels-photo-31443060.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '45 g', price: 55, category: 'Chocolates & Candies', recordedStock: 55, verifiedStock: null, dailySales: 12, supplierLeadTime: 5 },

  // === Chips & Snacks (3) ===
  { sku: 'SNK-001', name: 'Lays Classic Salted Chips', brand: 'Lays', image: 'https://images.pexels.com/photos/6485538/pexels-photo-6485538.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '52 g', price: 20, category: 'Chips & Snacks', recordedStock: 90, verifiedStock: 88, dailySales: 50, supplierLeadTime: 3 },
  { sku: 'SNK-002', name: 'Bingo Mad Angles Chips', brand: 'Bingo', image: 'https://images.pexels.com/photos/19993431/pexels-photo-19993431.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '60 g', price: 20, category: 'Chips & Snacks', recordedStock: 5, verifiedStock: null, dailySales: 30, supplierLeadTime: 3 },
  { sku: 'SNK-003', name: 'Haldiram Aloo Bhujia', brand: 'Haldiram', image: 'https://images.pexels.com/photos/6485578/pexels-photo-6485578.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 g', price: 55, category: 'Chips & Snacks', recordedStock: 40, verifiedStock: 40, dailySales: 20, supplierLeadTime: 4 },

  // === Instant Noodles (3) ===
  { sku: 'NOD-001', name: 'Maggi 2-Min Masala Noodles', brand: 'Maggi', image: 'https://images.pexels.com/photos/4541341/pexels-photo-4541341.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '70 g', price: 14, category: 'Instant Noodles', recordedStock: 150, verifiedStock: 145, dailySales: 80, supplierLeadTime: 2 },
  { sku: 'NOD-002', name: 'Top Ramen Curry Noodles', brand: 'Top Ramen', image: 'https://images.pexels.com/photos/8992932/pexels-photo-8992932.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '70 g', price: 14, category: 'Instant Noodles', recordedStock: 0, verifiedStock: null, dailySales: 40, supplierLeadTime: 3 },
  { sku: 'NOD-003', name: 'Yippee Magic Masala Noodles', brand: 'Sunfeast', image: 'https://images.pexels.com/photos/13085835/pexels-photo-13085835.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '75 g', price: 15, category: 'Instant Noodles', recordedStock: 60, verifiedStock: 58, dailySales: 35, supplierLeadTime: 3 },

  // === Soft Drinks (4) ===
  { sku: 'SFT-001', name: 'Coca-Cola Classic', brand: 'Coca-Cola', image: 'https://images.pexels.com/photos/17650224/pexels-photo-17650224.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 40, category: 'Soft Drinks', recordedStock: 70, verifiedStock: 70, dailySales: 45, supplierLeadTime: 2 },
  { sku: 'SFT-002', name: 'Pepsi Soft Drink', brand: 'Pepsi', image: 'https://images.pexels.com/photos/31966524/pexels-photo-31966524.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 40, category: 'Soft Drinks', recordedStock: 18, verifiedStock: 15, dailySales: 38, supplierLeadTime: 2 },
  { sku: 'SFT-003', name: 'Sprite Lemon-Lime Soda', brand: 'Coca-Cola', image: 'https://images.pexels.com/photos/34405411/pexels-photo-34405411.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 40, category: 'Soft Drinks', recordedStock: 50, verifiedStock: null, dailySales: 30, supplierLeadTime: 2 },
  { sku: 'SFT-004', name: 'Thums Up Cola', brand: 'Coca-Cola', image: 'https://images.pexels.com/photos/5869812/pexels-photo-5869812.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '600 ml', price: 38, category: 'Soft Drinks', recordedStock: 85, verifiedStock: 82, dailySales: 25, supplierLeadTime: 2 },

  // === Juices & Energy Drinks (3) ===
  { sku: 'JUC-001', name: 'Real Mixed Fruit Juice', brand: 'Real', image: 'https://images.pexels.com/photos/27119207/pexels-photo-27119207.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 110, category: 'Juices & Energy Drinks', recordedStock: 25, verifiedStock: 25, dailySales: 10, supplierLeadTime: 4 },
  { sku: 'JUC-002', name: 'Tropicana Orange Juice', brand: 'Tropicana', image: 'https://images.pexels.com/photos/15823268/pexels-photo-15823268.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 120, category: 'Juices & Energy Drinks', recordedStock: 14, verifiedStock: 12, dailySales: 12, supplierLeadTime: 4 },
  { sku: 'JUC-003', name: 'Red Bull Energy Drink', brand: 'Red Bull', image: 'https://images.pexels.com/photos/32329706/pexels-photo-32329706.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '250 ml', price: 125, category: 'Juices & Energy Drinks', recordedStock: 40, verifiedStock: null, dailySales: 8, supplierLeadTime: 5 },

  // === Tea & Coffee (4) ===
  { sku: 'TEA-001', name: 'Tata Tea Premium', brand: 'Tata', image: 'https://images.pexels.com/photos/33489599/pexels-photo-33489599.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 275, category: 'Tea & Coffee', recordedStock: 30, verifiedStock: 30, dailySales: 8, supplierLeadTime: 5 },
  { sku: 'TEA-002', name: 'Bru Instant Coffee', brand: 'Bru', image: 'https://images.pexels.com/photos/5218478/pexels-photo-5218478.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 155, category: 'Tea & Coffee', recordedStock: 22, verifiedStock: 20, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'TEA-003', name: 'Nescafe Classic Coffee', brand: 'Nescafe', image: 'https://images.pexels.com/photos/5071493/pexels-photo-5071493.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '50 g', price: 130, category: 'Tea & Coffee', recordedStock: 45, verifiedStock: null, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'TEA-004', name: 'Red Label Tea', brand: 'Brooke Bond', image: 'https://images.pexels.com/photos/30742323/pexels-photo-30742323.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 270, category: 'Tea & Coffee', recordedStock: 6, verifiedStock: null, dailySales: 12, supplierLeadTime: 5 },

  // === Rice (3) ===
  { sku: 'RIC-001', name: 'India Gate Basmati Rice', brand: 'India Gate', image: 'https://images.pexels.com/photos/15046838/pexels-photo-15046838.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 120, category: 'Rice', recordedStock: 50, verifiedStock: 48, dailySales: 12, supplierLeadTime: 7 },
  { sku: 'RIC-002', name: 'Daawat Devaaya Basmati', brand: 'Daawat', image: 'https://images.pexels.com/photos/28674713/pexels-photo-28674713.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 99, category: 'Rice', recordedStock: 35, verifiedStock: null, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'RIC-003', name: 'Sona Masoori Rice', brand: 'India Gate', image: 'https://images.pexels.com/photos/105588/pexels-photo-105588.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '5 kg', price: 450, category: 'Rice', recordedStock: 20, verifiedStock: 20, dailySales: 5, supplierLeadTime: 7 },

  // === Wheat Flour & Atta (3) ===
  { sku: 'WHT-001', name: 'Aashirvaad Whole Wheat Atta', brand: 'Aashirvaad', image: 'https://images.pexels.com/photos/16620746/pexels-photo-16620746.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '5 kg', price: 230, category: 'Wheat Flour & Atta', recordedStock: 40, verifiedStock: 38, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'WHT-002', name: 'Pillsbury Chakki Fresh Atta', brand: 'Pillsbury', image: 'https://images.pexels.com/photos/32812395/pexels-photo-32812395.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '5 kg', price: 240, category: 'Wheat Flour & Atta', recordedStock: 15, verifiedStock: null, dailySales: 12, supplierLeadTime: 5 },
  { sku: 'WHT-003', name: 'Fortune Chakki Fresh Atta', brand: 'Fortune', image: 'https://images.pexels.com/photos/11288849/pexels-photo-11288849.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '10 kg', price: 450, category: 'Wheat Flour & Atta', recordedStock: 25, verifiedStock: 25, dailySales: 6, supplierLeadTime: 5 },

  // === Pulses & Lentils (4) ===
  { sku: 'PUL-001', name: 'Tata Toor Dal', brand: 'Tata', image: 'https://images.pexels.com/photos/34949285/pexels-photo-34949285.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 160, category: 'Pulses & Lentils', recordedStock: 30, verifiedStock: 30, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'PUL-002', name: 'Organic Tattva Moong Dal', brand: 'Organic Tattva', image: 'https://images.pexels.com/photos/36930125/pexels-photo-36930125.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 120, category: 'Pulses & Lentils', recordedStock: 20, verifiedStock: 18, dailySales: 5, supplierLeadTime: 7 },
  { sku: 'PUL-003', name: 'Tata Chana Dal', brand: 'Tata', image: 'https://images.pexels.com/photos/7090156/pexels-photo-7090156.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 130, category: 'Pulses & Lentils', recordedStock: 18, verifiedStock: null, dailySales: 6, supplierLeadTime: 7 },
  { sku: 'PUL-004', name: 'India Gate Kabuli Chana', brand: 'India Gate', image: 'https://images.pexels.com/photos/22391699/pexels-photo-22391699.png?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 150, category: 'Pulses & Lentils', recordedStock: 22, verifiedStock: 22, dailySales: 4, supplierLeadTime: 7 },

  // === Cooking Oils (4) ===
  { sku: 'OIL-001', name: 'Fortune Sunflower Oil', brand: 'Fortune', image: 'https://images.pexels.com/photos/9070120/pexels-photo-9070120.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 130, category: 'Cooking Oils', recordedStock: 60, verifiedStock: 58, dailySales: 18, supplierLeadTime: 5 },
  { sku: 'OIL-002', name: 'Saffola Gold Refined Oil', brand: 'Saffola', image: 'https://images.pexels.com/photos/30801238/pexels-photo-30801238.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 160, category: 'Cooking Oils', recordedStock: 12, verifiedStock: null, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'OIL-003', name: 'Dhara Mustard Oil', brand: 'Dhara', image: 'https://images.pexels.com/photos/39105767/pexels-photo-39105767.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 145, category: 'Cooking Oils', recordedStock: 40, verifiedStock: 40, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'OIL-004', name: 'Figaro Olive Oil', brand: 'Figaro', image: 'https://images.pexels.com/photos/34270746/pexels-photo-34270746.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 ml', price: 280, category: 'Cooking Oils', recordedStock: 15, verifiedStock: 14, dailySales: 4, supplierLeadTime: 7 },

  // === Salt & Sugar (3) ===
  { sku: 'SAL-001', name: 'Tata Salt Iodised', brand: 'Tata', image: 'https://images.pexels.com/photos/6246099/pexels-photo-6246099.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 28, category: 'Salt & Sugar', recordedStock: 100, verifiedStock: 98, dailySales: 20, supplierLeadTime: 7 },
  { sku: 'SAL-002', name: 'Madhur Pure Sugar', brand: 'Madhur', image: 'https://images.pexels.com/photos/29039080/pexels-photo-29039080.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 45, category: 'Salt & Sugar', recordedStock: 50, verifiedStock: null, dailySales: 15, supplierLeadTime: 7 },
  { sku: 'SAL-003', name: 'Aashirvaad Salt', brand: 'Aashirvaad', image: 'https://images.pexels.com/photos/17525097/pexels-photo-17525097.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 25, category: 'Salt & Sugar', recordedStock: 80, verifiedStock: 80, dailySales: 18, supplierLeadTime: 7 },

  // === Spices & Masalas (4) ===
  { sku: 'SPC-001', name: 'MDH Garam Masala', brand: 'MDH', image: 'https://images.pexels.com/photos/32038446/pexels-photo-32038446.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 55, category: 'Spices & Masalas', recordedStock: 45, verifiedStock: 45, dailySales: 12, supplierLeadTime: 5 },
  { sku: 'SPC-002', name: 'Everest Turmeric Powder', brand: 'Everest', image: 'https://images.pexels.com/photos/13779108/pexels-photo-13779108.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 g', price: 60, category: 'Spices & Masalas', recordedStock: 30, verifiedStock: 28, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'SPC-003', name: 'Catch Red Chilli Powder', brand: 'Catch', image: 'https://images.pexels.com/photos/35156984/pexels-photo-35156984.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 g', price: 70, category: 'Spices & Masalas', recordedStock: 5, verifiedStock: null, dailySales: 14, supplierLeadTime: 5 },
  { sku: 'SPC-004', name: 'MDH Chicken Masala', brand: 'MDH', image: 'https://images.pexels.com/photos/7829483/pexels-photo-7829483.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 g', price: 50, category: 'Spices & Masalas', recordedStock: 35, verifiedStock: 35, dailySales: 8, supplierLeadTime: 5 },

  // === Breakfast Cereals (3) ===
  { sku: 'CER-001', name: 'Kelloggs Corn Flakes', brand: 'Kelloggs', image: 'https://images.pexels.com/photos/6948044/pexels-photo-6948044.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '875 g', price: 290, category: 'Breakfast Cereals', recordedStock: 25, verifiedStock: 24, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'CER-002', name: 'Bagrrys White Oats', brand: 'Bagrrys', image: 'https://images.pexels.com/photos/6553454/pexels-photo-6553454.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 199, category: 'Breakfast Cereals', recordedStock: 18, verifiedStock: null, dailySales: 6, supplierLeadTime: 7 },
  { sku: 'CER-003', name: 'Muesli Crunchy Cereal', brand: 'Kelloggs', image: 'https://images.pexels.com/photos/37180554/pexels-photo-37180554.png?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 250, category: 'Breakfast Cereals', recordedStock: 30, verifiedStock: 30, dailySales: 5, supplierLeadTime: 7 },

  // === Frozen Foods (3) ===
  { sku: 'FRZ-001', name: 'McCain French Fries', brand: 'McCain', image: 'https://images.pexels.com/photos/5041473/pexels-photo-5041473.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 g', price: 99, category: 'Frozen Foods', recordedStock: 35, verifiedStock: 33, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'FRZ-002', name: 'ITC Master Chef Veg Nuggets', brand: 'ITC', image: 'https://images.pexels.com/photos/15801054/pexels-photo-15801054.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 g', price: 120, category: 'Frozen Foods', recordedStock: 20, verifiedStock: null, dailySales: 8, supplierLeadTime: 5 },
  { sku: 'FRZ-003', name: 'Frozen Green Peas', brand: 'McCain', image: 'https://images.pexels.com/photos/39624859/pexels-photo-39624859.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 80, category: 'Frozen Foods', recordedStock: 40, verifiedStock: 40, dailySales: 12, supplierLeadTime: 5 },

  // === Ice Cream (3) ===
  { sku: 'ICR-001', name: 'Amul Vanilla Magic', brand: 'Amul', image: 'https://images.pexels.com/photos/7761734/pexels-photo-7761734.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '700 ml', price: 199, category: 'Ice Cream', recordedStock: 25, verifiedStock: 23, dailySales: 12, supplierLeadTime: 2 },
  { sku: 'ICR-002', name: 'Kwality Walls Chocobar', brand: 'Kwality Walls', image: 'https://images.pexels.com/photos/30627481/pexels-photo-30627481.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '6 pcs', price: 180, category: 'Ice Cream', recordedStock: 8, verifiedStock: null, dailySales: 15, supplierLeadTime: 2 },
  { sku: 'ICR-003', name: 'Mother Dairy Strawberry', brand: 'Mother Dairy', image: 'https://images.pexels.com/photos/5535554/pexels-photo-5535554.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '650 ml', price: 180, category: 'Ice Cream', recordedStock: 30, verifiedStock: 30, dailySales: 10, supplierLeadTime: 2 },

  // === Packaged Foods (4) ===
  { sku: 'PCK-001', name: 'MTR Rava Idli Mix', brand: 'MTR', image: 'https://images.pexels.com/photos/35740586/pexels-photo-35740586.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 85, category: 'Packaged Foods', recordedStock: 30, verifiedStock: 30, dailySales: 8, supplierLeadTime: 5 },
  { sku: 'PCK-002', name: 'Kitchens of India Dal', brand: 'ITC', image: 'https://images.pexels.com/photos/6901810/pexels-photo-6901810.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 g', price: 120, category: 'Packaged Foods', recordedStock: 15, verifiedStock: 13, dailySales: 6, supplierLeadTime: 5 },
  { sku: 'PCK-003', name: 'Haldiram Bhujia Sev', brand: 'Haldiram', image: 'https://images.pexels.com/photos/20141098/pexels-photo-20141098.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 220, category: 'Packaged Foods', recordedStock: 25, verifiedStock: null, dailySales: 10, supplierLeadTime: 4 },
  { sku: 'PCK-004', name: 'Maggi Pazzta Cheese Macaroni', brand: 'Maggi', image: 'https://images.pexels.com/photos/13661818/pexels-photo-13661818.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '70 g', price: 45, category: 'Packaged Foods', recordedStock: 50, verifiedStock: 50, dailySales: 15, supplierLeadTime: 4 },

  // === Personal Care (4) ===
  { sku: 'PER-001', name: 'Dove Cream Beauty Bar', brand: 'Dove', image: 'https://images.pexels.com/photos/14382430/pexels-photo-14382430.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '125 g', price: 55, category: 'Personal Care', recordedStock: 60, verifiedStock: 58, dailySales: 20, supplierLeadTime: 5 },
  { sku: 'PER-002', name: 'Lux Velvet Soap Bar', brand: 'Lux', image: 'https://images.pexels.com/photos/29502141/pexels-photo-29502141.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '150 g', price: 42, category: 'Personal Care', recordedStock: 40, verifiedStock: null, dailySales: 25, supplierLeadTime: 5 },
  { sku: 'PER-003', name: 'Nivea Body Lotion', brand: 'Nivea', image: 'https://images.pexels.com/photos/4832435/pexels-photo-4832435.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 ml', price: 295, category: 'Personal Care', recordedStock: 18, verifiedStock: 18, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'PER-004', name: 'Fogg Deodorant Spray', brand: 'Fogg', image: 'https://images.pexels.com/photos/17427500/pexels-photo-17427500.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '150 ml', price: 220, category: 'Personal Care', recordedStock: 10, verifiedStock: null, dailySales: 12, supplierLeadTime: 7 },

  // === Oral Care (3) ===
  { sku: 'ORL-001', name: 'Colgate Strong Teeth Paste', brand: 'Colgate', image: 'https://images.pexels.com/photos/8842706/pexels-photo-8842706.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 g', price: 115, category: 'Oral Care', recordedStock: 50, verifiedStock: 48, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'ORL-002', name: 'Sensodyne Fresh Mint', brand: 'Sensodyne', image: 'https://images.pexels.com/photos/9951399/pexels-photo-9951399.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '75 g', price: 140, category: 'Oral Care', recordedStock: 20, verifiedStock: null, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'ORL-003', name: 'Oral-B CrossAction Brush', brand: 'Oral-B', image: 'https://images.pexels.com/photos/7352968/pexels-photo-7352968.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '2 pcs', price: 95, category: 'Oral Care', recordedStock: 35, verifiedStock: 35, dailySales: 8, supplierLeadTime: 5 },

  // === Hair Care (3) ===
  { sku: 'HAR-001', name: 'Head & Shoulders Shampoo', brand: 'Head & Shoulders', image: 'https://images.pexels.com/photos/19833253/pexels-photo-19833253.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '340 ml', price: 280, category: 'Hair Care', recordedStock: 25, verifiedStock: 24, dailySales: 10, supplierLeadTime: 7 },
  { sku: 'HAR-002', name: 'Dove Conditioner', brand: 'Dove', image: 'https://images.pexels.com/photos/33525723/pexels-photo-33525723.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '340 ml', price: 260, category: 'Hair Care', recordedStock: 12, verifiedStock: null, dailySales: 12, supplierLeadTime: 7 },
  { sku: 'HAR-003', name: 'Parachute Coconut Hair Oil', brand: 'Parachute', image: 'https://images.pexels.com/photos/18066458/pexels-photo-18066458.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '300 ml', price: 120, category: 'Hair Care', recordedStock: 40, verifiedStock: 40, dailySales: 15, supplierLeadTime: 5 },

  // === Skin Care (4) ===
  { sku: 'SKN-001', name: 'Garnier Light Face Wash', brand: 'Garnier', image: 'https://images.pexels.com/photos/33538456/pexels-photo-33538456.png?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 ml', price: 150, category: 'Skin Care', recordedStock: 30, verifiedStock: 28, dailySales: 12, supplierLeadTime: 7 },
  { sku: 'SKN-002', name: 'Nivea Soft Light Moisturiser', brand: 'Nivea', image: 'https://images.pexels.com/photos/36339062/pexels-photo-36339062.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '50 ml', price: 199, category: 'Skin Care', recordedStock: 18, verifiedStock: null, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'SKN-003', name: 'Himalaya Face Wash Gel', brand: 'Himalaya', image: 'https://images.pexels.com/photos/33537354/pexels-photo-33537354.png?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '100 ml', price: 135, category: 'Skin Care', recordedStock: 22, verifiedStock: 22, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'SKN-004', name: 'Lakme Sunscreen SPF 50', brand: 'Lakme', image: 'https://images.pexels.com/photos/27561830/pexels-photo-27561830.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '50 ml', price: 350, category: 'Skin Care', recordedStock: 7, verifiedStock: 5, dailySales: 9, supplierLeadTime: 7 },

  // === Laundry Products (3) ===
  { sku: 'LND-001', name: 'Surf Excel Detergent Powder', brand: 'Surf Excel', image: 'https://images.pexels.com/photos/31526215/pexels-photo-31526215.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 130, category: 'Laundry Products', recordedStock: 40, verifiedStock: 38, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'LND-002', name: 'Ariel Matic Liquid Detergent', brand: 'Ariel', image: 'https://images.pexels.com/photos/39302977/pexels-photo-39302977.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 L', price: 210, category: 'Laundry Products', recordedStock: 14, verifiedStock: null, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'LND-003', name: 'Comfort Fabric Conditioner', brand: 'Comfort', image: 'https://images.pexels.com/photos/12104070/pexels-photo-12104070.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '860 ml', price: 175, category: 'Laundry Products', recordedStock: 25, verifiedStock: 25, dailySales: 8, supplierLeadTime: 5 },

  // === Home Cleaning (4) ===
  { sku: 'CLN-001', name: 'Harpic Toilet Cleaner', brand: 'Harpic', image: 'https://images.pexels.com/photos/12997255/pexels-photo-12997255.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 85, category: 'Home Cleaning', recordedStock: 30, verifiedStock: 30, dailySales: 10, supplierLeadTime: 5 },
  { sku: 'CLN-002', name: 'Lizol Floor Cleaner', brand: 'Lizol', image: 'https://images.pexels.com/photos/12997254/pexels-photo-12997254.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '975 ml', price: 175, category: 'Home Cleaning', recordedStock: 15, verifiedStock: 13, dailySales: 8, supplierLeadTime: 5 },
  { sku: 'CLN-003', name: 'Colin Glass Cleaner', brand: 'Colin', image: 'https://images.pexels.com/photos/9225633/pexels-photo-9225633.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 ml', price: 90, category: 'Home Cleaning', recordedStock: 20, verifiedStock: null, dailySales: 7, supplierLeadTime: 5 },
  { sku: 'CLN-004', name: 'Domex Disinfectant', brand: 'Domex', image: 'https://images.pexels.com/photos/28921817/pexels-photo-28921817.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 80, category: 'Home Cleaning', recordedStock: 35, verifiedStock: 35, dailySales: 9, supplierLeadTime: 5 },

  // === Dishwashing Products (3) ===
  { sku: 'DSH-001', name: 'Vim Dishwash Liquid Gel', brand: 'Vim', image: 'https://images.pexels.com/photos/14382430/pexels-photo-14382430.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '750 ml', price: 110, category: 'Dishwashing Products', recordedStock: 40, verifiedStock: 38, dailySales: 15, supplierLeadTime: 5 },
  { sku: 'DSH-002', name: 'Pril Dishwash Gel', brand: 'Pril', image: 'https://images.pexels.com/photos/29502138/pexels-photo-29502138.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '725 ml', price: 95, category: 'Dishwashing Products', recordedStock: 8, verifiedStock: null, dailySales: 12, supplierLeadTime: 5 },
  { sku: 'DSH-003', name: 'Exo Dishwash Bar', brand: 'Exo', image: 'https://images.pexels.com/photos/13003436/pexels-photo-13003436.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '700 g', price: 50, category: 'Dishwashing Products', recordedStock: 60, verifiedStock: 60, dailySales: 20, supplierLeadTime: 5 },

  // === Baby Care (3) ===
  { sku: 'BAB-001', name: 'Pampers Baby Diapers L', brand: 'Pampers', image: 'https://images.pexels.com/photos/21268301/pexels-photo-21268301.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '32 pcs', price: 499, category: 'Baby Care', recordedStock: 25, verifiedStock: 23, dailySales: 8, supplierLeadTime: 7 },
  { sku: 'BAB-002', name: 'Johnson Baby Shampoo', brand: 'Johnson', image: 'https://images.pexels.com/photos/15427723/pexels-photo-15427723.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '200 ml', price: 215, category: 'Baby Care', recordedStock: 15, verifiedStock: null, dailySales: 6, supplierLeadTime: 7 },
  { sku: 'BAB-003', name: 'Himalaya Baby Powder', brand: 'Himalaya', image: 'https://images.pexels.com/photos/13779115/pexels-photo-13779115.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '400 g', price: 180, category: 'Baby Care', recordedStock: 20, verifiedStock: 20, dailySales: 5, supplierLeadTime: 7 },

  // === Pet Care (3) ===
  { sku: 'PET-001', name: 'Pedigree Adult Dog Food', brand: 'Pedigree', image: 'https://images.pexels.com/photos/13581209/pexels-photo-13581209.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1.2 kg', price: 350, category: 'Pet Care', recordedStock: 18, verifiedStock: 17, dailySales: 5, supplierLeadTime: 7 },
  { sku: 'PET-002', name: 'Whiskas Cat Food Tuna', brand: 'Whiskas', image: 'https://images.pexels.com/photos/17309676/pexels-photo-17309676.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 kg', price: 280, category: 'Pet Care', recordedStock: 10, verifiedStock: null, dailySales: 4, supplierLeadTime: 7 },
  { sku: 'PET-003', name: 'Drools Chicken Dog Food', brand: 'Drools', image: 'https://images.pexels.com/photos/160839/cat-animal-love-pet-160839.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1.2 kg', price: 320, category: 'Pet Care', recordedStock: 22, verifiedStock: 22, dailySales: 3, supplierLeadTime: 7 },

  // === Household Essentials (3) ===
  { sku: 'HSE-001', name: 'Eveready AA Batteries', brand: 'Eveready', image: 'https://images.pexels.com/photos/577514/pexels-photo-577514.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '4 pcs', price: 60, category: 'Household Essentials', recordedStock: 100, verifiedStock: 98, dailySales: 15, supplierLeadTime: 7 },
  { sku: 'HSE-002', name: 'Philips LED Bulb 9W', brand: 'Philips', image: 'https://images.pexels.com/photos/20943579/pexels-photo-20943579.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '1 pc', price: 150, category: 'Household Essentials', recordedStock: 30, verifiedStock: null, dailySales: 6, supplierLeadTime: 7 },
  { sku: 'HSE-003', name: 'Surf Excel Washing Bar', brand: 'Surf Excel', image: 'https://images.pexels.com/photos/3250031/pexels-photo-3250031.jpeg?auto=compress&cs=tinysrgb&h=350&w=350', packageSize: '500 g', price: 45, category: 'Household Essentials', recordedStock: 50, verifiedStock: 50, dailySales: 10, supplierLeadTime: 7 },
];
