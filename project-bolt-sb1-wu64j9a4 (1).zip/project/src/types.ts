export type RiskLevel = 'high' | 'medium' | 'low';

export type View = 'dashboard' | 'catalog' | 'phantom' | 'predictions' | 'product-detail';

export interface Product {
  sku: string;
  name: string;
  brand: string;
  image: string;
  packageSize: string;
  price: number;
  category: string;
  recordedStock: number;
  verifiedStock: number | null;
  dailySales: number;
  supplierLeadTime: number;
}

export interface ProductWithMetrics extends Product {
  stockOutRisk: RiskLevel;
  riskScore: number;
  phantomDiscrepancy: number | null;
  estimatedStockOutDays: number | null;
  recommendedAction: string;
  reorderQuantity: number;
  riskExplanation: string;
}

export interface DashboardMetrics {
  totalProducts: number;
  totalCategories: number;
  totalInventoryValue: number;
  highRiskCount: number;
  suspectedPhantomCount: number;
  predictedStockOuts: number;
}
